export interface IProduct {
    productID: number;
    productName: string;
    productPrice: number; 
    vendor: string
    discount: number
    productImage: string
  }
  