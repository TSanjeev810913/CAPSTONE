﻿using System;
using System.Collections.Generic;
using System.Text;

namespace QuickKart_DataAccessLayer
{
    public class AdminRepository
    {






    }
}
